# Leasibility AI — Layout Generation Module

**Version:** 1.0 (extracted from production app, March 2026)
**Purpose:** Standalone developer evaluation package — run, inspect, and improve the layout engine in isolation.

---

## What This Module Does

This module contains the **deterministic layout generation engine** used by Leasibility AI to produce test-fit space plans for commercial office spaces. Given a rectangular floorplate, an entry door location, a room program (list of space types with counts and areas), and a design scenario, it returns:

- A list of **placed rooms** with their type, position (x, y in feet), dimensions, area, and zone classification (perimeter vs interior).
- A list of **circulation corridors** with their geometry.
- A set of **placement statistics** (efficiency score, placed sq ft, residual sq ft).
- An **SVG string** that can be written to a `.svg` file or embedded in HTML for immediate visual inspection.

The module runs entirely in-process. It has **no external dependencies**, requires no API keys, no database, and no authentication.

---

## File Structure

```
leasibility-layout-module/
├── src/
│   ├── index.ts              ← Main entry point — export generateTestFit()
│   ├── layoutEngine.ts       ← Core room placement engine (row-based packer)
│   ├── corridorGenerator.ts  ← Circulation spine and cross-corridor generation
│   ├── placementRules.ts     ← Per-room-type placement preferences and priorities
│   ├── geometry.ts           ← 2D geometry primitives (overlap, contains, snap, etc.)
│   └── svgRenderer.ts        ← Converts LayoutOutput to an SVG string
├── run-sample.mjs            ← Node.js runner — generates sample-output.json + .svg
├── sample-input.json         ← Example input: 8,500 sf / 35 people / Balanced Standard
├── sample-output.json        ← Generated output from sample-input.json
├── sample-output.svg         ← Visual SVG output from sample-input.json
└── README.md                 ← This file
```

---

## Quick Start

**No compile step required** — the runner uses plain JavaScript.

```bash
node run-sample.mjs
```

This reads `sample-input.json`, runs the layout engine, and writes:
- `sample-output.json` — full placement result with room positions and stats
- `sample-output.svg`  — visual floor plan (open in any browser or SVG viewer)

To use the TypeScript source directly in your own project:

```ts
import { generateTestFit } from "./src/index";
import input from "./sample-input.json";

const result = generateTestFit(input);
console.log(result.rooms);          // placed rooms with positions
console.log(result.stats);          // efficiency, sq ft breakdown
// write result.svg to a file for visual inspection
```

---

## Input Schema

```ts
interface TestFitInput {
  floorplate: {
    x: number;       // origin x (ft) — typically 0
    y: number;       // origin y (ft) — typically 0
    width: number;   // floorplate width (ft)
    height: number;  // floorplate depth (ft)
  };
  entryLocation: {
    x: number;       // entry door x position (ft from origin)
    y: number;       // entry door y position (ft from origin)
  };
  program: Array<{
    type: string;    // room type name (see placementRules.ts for valid types)
    count: number;   // number of this room type
    sqFt: number;    // target area per unit (sq ft)
  }>;
  scenario: "collaborative-hub" | "balanced-standard" | "privacy-first";
  label?: string;    // optional label shown in SVG footer
}
```

### Scenario Definitions

| Scenario | Strategy | Focus / Collab Split | Density |
|---|---|---|---|
| `collaborative-hub` | Adaptive — open plan dominates | 50% / 50% | 0.7 desks/person |
| `balanced-standard` | Core — mixed perimeter + interior | 65% / 35% | 1.0 desk/person |
| `privacy-first` | Perimeter — private offices line the walls | 80% / 20% | High private office ratio |

---

## Output Schema

```ts
interface TestFitOutput {
  rooms: Array<{
    id: string;
    type: string;
    position: { x: number; y: number };  // bottom-left corner (ft)
    width: number;    // ft
    height: number;   // ft
    area: number;     // sq ft (actual placed)
    zone: "perimeter" | "interior";
  }>;
  corridors: Array<{
    id: string;
    axis: "horizontal" | "vertical";
    x: number; y: number; width: number; height: number;
  }>;
  unplacedRooms: Array<{
    type: string;
    count: number;
    reason: string;
  }>;
  stats: {
    efficiencyScore: number;      // 0–1
    efficiencyPercent: number;    // 0–100
    placedSqFt: number;
    corridorSqFt: number;
    residualSqFt: number;
    totalFloorplateSqFt: number;
  };
  svg: string;  // inline SVG — write to .svg or embed in HTML
}
```

---

## What Is Currently NOT Working Correctly

The following issues are present in the v1 engine and are the primary reasons why generated layouts do not meet architectural quality standards.

### 1. Row-Based Packing — No Spatial Intelligence

The current placement algorithm is a simple **row-based bin packer**: it scans the floorplate from left to right, top to bottom, and places each room in the first available cell that does not overlap any previously placed room or corridor. This approach has no understanding of spatial relationships, adjacency, or zone preferences.

**Observed symptom:** Large rooms (e.g., Open Workspace at 3,200 sf) are frequently unplaced because small rooms have already fragmented the available space into cells too small to accommodate them. The sample run demonstrates this: 17 small rooms are placed but the primary workspace cannot fit, leaving 57% of the floorplate as residual space.

### 2. Weak Adjacency Logic

The placement rules file (`placementRules.ts`) defines which room types should be adjacent to each other — for example, Reception near Conference Rooms, Break Room near Open Workspace. However, the scoring function applies these preferences only as a **mild score bonus after the fact**. It does not constrain placement to enforce adjacency, nor does it use an adjacency graph to sequence placement decisions.

**Observed symptom:** Conference rooms may end up on the opposite side of the floor from Reception. Break rooms may be isolated from the open workspace they are meant to serve. The layout looks like a random scatter rather than a coherent office plan.

### 3. Inconsistent Corridor Behaviour

The corridor generator places a single horizontal spine at the vertical midpoint of the floorplate, plus a vertical cross-corridor if the floor is wide enough. The corridor does not respond to the entry location, does not branch to serve room clusters that are far from the spine, and does not avoid reserved core zones (stairs, elevators, restrooms).

**Observed symptom:** The corridor bisects the floor regardless of where the entry door is. Rooms placed above the spine have no circulation connection to rooms below it. On narrow floors, no cross-corridor is generated at all, leaving entire zones unreachable.

### 4. No Large-Room Priority

The packer processes rooms in `placementOrder` sequence (anchors first, then primary work zones, then support spaces). While this is correct in principle, the current implementation does not reserve a contiguous zone for large rooms before placing small rooms. As a result, small rooms fragment the available space before the large Open Workspace can be placed.

**Observed symptom:** Open Workspace — the largest and most important room in most programs — is frequently the last room placed and the first to fail.

### 5. No Overlap Resolution Pass

After initial placement, there is no post-processing pass to detect and resolve near-overlaps caused by floating-point rounding or grid snapping. Rooms placed at grid boundaries may visually appear to touch or slightly overlap in the SVG output.

---

## What Needs to Be Improved

The following improvements are listed in priority order. Addressing items 1–3 would produce architecturally credible layouts for the majority of standard office programs.

### Priority 1 — Anchor-Based Placement

**Goal:** Place Reception and Conference Rooms first, anchored to the entry location and the building perimeter. All other rooms are then placed relative to these anchors.

**Approach:**
1. Identify the entry wall (the floorplate edge closest to `entryLocation`).
2. Place Reception immediately inside the entry, flush against the entry wall.
3. Place Conference Rooms adjacent to Reception, extending along the perimeter.
4. Use the Reception centroid as the origin of the primary circulation spine.
5. Place all remaining rooms relative to the spine, respecting zone preferences.

This single change would transform the layout from a random scatter into a recognisable office plan with a clear front-of-house / back-of-house organisation.

### Priority 2 — Large-Room Reservation

**Goal:** Guarantee that the Open Workspace (and any other room with `sqFt > 1,000`) is always placed successfully.

**Approach:**
1. Before placing any room, compute the total area required by all large rooms.
2. Reserve a contiguous rectangular zone in the interior of the floorplate for the open workspace.
3. Place all other rooms around the reserved zone, not inside it.
4. After all other rooms are placed, fill the reserved zone with the open workspace.

### Priority 3 — Perimeter vs Interior Zone Enforcement

**Goal:** Private offices should line the perimeter (window access). Open workspace and support rooms should occupy the interior.

**Approach:**
1. Divide the floorplate into a perimeter band (15 ft deep from each edge) and an interior zone.
2. For rooms with `preferredZone: "perimeter"`, restrict candidate positions to the perimeter band.
3. For rooms with `preferredZone: "interior"`, restrict candidate positions to the interior zone.
4. Only allow cross-zone placement when the preferred zone is fully packed.

### Priority 4 — Entry-Anchored Corridor Spine

**Goal:** The primary circulation corridor should originate at the entry door and extend toward the building core, not simply bisect the floor at the midpoint.

**Approach:**
1. Detect the entry wall from `entryLocation`.
2. Project a corridor spine perpendicular to the entry wall, from the entry toward the opposite wall.
3. Add branch corridors (minimum 5 ft wide) at regular intervals to serve room clusters on either side of the spine.
4. Ensure the corridor network connects all placed rooms to the entry without dead ends.

### Priority 5 — Non-Linear, Puzzle-Like Placement

**Goal:** Rooms should fit together like puzzle pieces — no wasted corridors of leftover space between rooms, no isolated pockets that cannot be reached.

**Approach:**
1. After initial placement, run a **compaction pass**: slide each room toward its nearest anchor or corridor until it is flush with an adjacent room or wall.
2. Fill residual pockets with flexible-use rooms (Storage, Print Area, Phone Booths) sized to fit the available space.
3. If residual space exceeds 10% of the floorplate, flag it as a program mismatch and suggest adding rooms or reducing room sizes.

### Priority 6 — Reliable Circulation Connectivity

**Goal:** Every placed room should have a door that opens directly onto a corridor or onto an adjacent room that connects to a corridor.

**Approach:**
1. After placement, build a connectivity graph: rooms are nodes, shared walls are edges.
2. Perform a breadth-first search from Reception (the entry anchor).
3. Any room not reachable from Reception within 2 hops is flagged as isolated.
4. Insert a branch corridor to connect isolated rooms to the nearest spine segment.

---

## Architecture Notes for the Implementing Developer

The module is structured so that each concern is isolated in its own file. The recommended order of improvement is:

1. **`placementRules.ts`** — Extend the adjacency graph and zone rules. No algorithmic changes required; this is pure data.
2. **`corridorGenerator.ts`** — Implement entry-anchored spine (Priority 4). The interface is already defined; only the implementation needs to change.
3. **`layoutEngine.ts`** — Replace the row-based packer with anchor-based placement (Priority 1) and large-room reservation (Priority 2). The `scorePosition()` function is the primary extension point.
4. **`svgRenderer.ts`** — No logic changes needed; this file only renders what the engine produces. Visual quality will improve automatically as the engine improves.

The `generateTestFit()` function in `src/index.ts` is the stable public API. Its input and output types should not change — only the internal implementation of `generateLayout()` in `layoutEngine.ts` needs to evolve.

---

## Excluded from This Package

The following components of the full Leasibility AI application are intentionally excluded:

- Authentication, OAuth, and session management
- Dashboard UI and all React components
- CRM and user data management
- Stripe billing and subscription logic
- PDF export and report generation
- AI image generation (the `generateImage()` call in `aiEngine.ts`)
- LLM-based room program generation (the `invokeLLM()` call in `aiEngine.ts`)
- Market cost benchmarks and schedule generation (these are data tables, not layout logic)
- Any API keys, secrets, or environment variables

The AI image generation and LLM calls in the production `aiEngine.ts` are **separate from the layout engine** — they are post-processing steps that generate a photorealistic rendering of the layout description. The deterministic layout logic extracted here is the foundation that the AI image prompt is built on top of.

---

## Contact

This package was prepared by the Leasibility AI development team for external developer evaluation. For questions about the production application, contact the project owner directly.
