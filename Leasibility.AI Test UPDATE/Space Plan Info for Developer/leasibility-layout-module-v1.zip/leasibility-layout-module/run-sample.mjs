/**
 * run-sample.mjs
 * Standalone runner — generates sample-output.json and sample-output.svg
 * from sample-input.json using the layout engine.
 *
 * Usage:
 *   node run-sample.mjs
 *
 * Requirements:
 *   Node.js 18+ with --experimental-vm-modules (for ESM TypeScript via tsx)
 *   OR compile first: npx tsc && node dist/run-sample.js
 *
 * Quick run with tsx (no compile step):
 *   npx tsx run-sample.mjs
 */

import { readFileSync, writeFileSync } from "fs";
import { fileURLToPath } from "url";
import { dirname, join } from "path";

const __dirname = dirname(fileURLToPath(import.meta.url));

// ── Inline the layout engine (compiled JS equivalent) ─────────
// We re-implement the core logic here in plain JS so this runner
// works without a TypeScript compile step. For production use,
// import from the compiled src/index.ts instead.

function snap(val, grid = 1) {
  return Math.round(val / grid) * grid;
}

function overlaps(a, b) {
  return (
    a.x < b.x + b.width &&
    a.x + a.width > b.x &&
    a.y < b.y + b.height &&
    a.y + a.height > b.y
  );
}

function contains(outer, inner) {
  return (
    inner.x >= outer.x &&
    inner.y >= outer.y &&
    inner.x + inner.width  <= outer.x + outer.width &&
    inner.y + inner.height <= outer.y + outer.height
  );
}

function clamp(val, min, max) {
  return Math.max(min, Math.min(max, val));
}

function dimensionsFromArea(targetSqFt, preferredAspect = 1.5, minDim = 8, maxDim = 60) {
  const h = clamp(snap(Math.sqrt(targetSqFt / preferredAspect)), minDim, maxDim);
  const w = clamp(snap(targetSqFt / h), minDim, maxDim);
  return { width: w, height: h };
}

function zoneOf(room, floorplate, perimeterDepth = 15) {
  const cx = room.x + room.width / 2;
  const cy = room.y + room.height / 2;
  const nearLeft   = cx - floorplate.x < perimeterDepth;
  const nearRight  = (floorplate.x + floorplate.width)  - cx < perimeterDepth;
  const nearBottom = cy - floorplate.y < perimeterDepth;
  const nearTop    = (floorplate.y + floorplate.height) - cy < perimeterDepth;
  return (nearLeft || nearRight || nearBottom || nearTop) ? "perimeter" : "interior";
}

function sharedEdgeLength(a, b) {
  if (Math.abs((a.x + a.width) - b.x) < 0.01 || Math.abs((b.x + b.width) - a.x) < 0.01) {
    const overlapY = Math.min(a.y + a.height, b.y + b.height) - Math.max(a.y, b.y);
    return Math.max(0, overlapY);
  }
  if (Math.abs((a.y + a.height) - b.y) < 0.01 || Math.abs((b.y + b.height) - a.y) < 0.01) {
    const overlapX = Math.min(a.x + a.width, b.x + b.width) - Math.max(a.x, b.x);
    return Math.max(0, overlapX);
  }
  return 0;
}

const PLACEMENT_ORDER = {
  "Reception": 1, "Conference Room": 2, "Huddle Room": 3,
  "Private Office": 4, "Open Workspace": 5, "Focus Room": 6,
  "Phone Booth": 7, "Break Room": 8, "Collaboration Zone": 9,
  "Lounge": 10, "Storage": 11, "Server Room": 12,
  "Print Area": 13, "IT Room": 14,
};

const PREFERRED_ASPECTS = {
  "Reception": 1.6, "Conference Room": 1.5, "Huddle Room": 1.2,
  "Private Office": 1.2, "Open Workspace": 2.0, "Phone Booth": 1.0,
  "Break Room": 1.4, "Collaboration Zone": 1.5, "Lounge": 1.6,
  "Storage": 1.3, "Server Room": 1.2, "Focus Room": 1.1,
  "Print Area": 1.2, "IT Room": 1.2,
};

const ADJACENT_TO = {
  "Reception": [], "Conference Room": ["Reception"],
  "Huddle Room": ["Open Workspace", "Conference Room"],
  "Private Office": [], "Open Workspace": ["Break Room", "Collaboration Zone"],
  "Break Room": ["Open Workspace", "Lounge"], "Collaboration Zone": ["Open Workspace"],
  "Phone Booth": ["Open Workspace"], "Focus Room": ["Open Workspace"],
  "Lounge": ["Break Room", "Reception"], "Storage": [], "Server Room": [],
  "Print Area": ["Open Workspace"], "IT Room": ["Server Room"],
};

const PREFERRED_ZONE = {
  "Reception": "perimeter", "Conference Room": "perimeter",
  "Private Office": "perimeter", "Lounge": "perimeter",
  "Open Workspace": "interior", "Huddle Room": "interior",
  "Focus Room": "interior", "Phone Booth": "interior",
  "Break Room": "interior", "Collaboration Zone": "interior",
  "Storage": "interior", "Server Room": "interior",
  "Print Area": "interior", "IT Room": "interior",
};

function scorePosition(candidate, floorplate, placed, roomType) {
  let score = 0;
  const zone = zoneOf(candidate, floorplate);
  const prefZone = PREFERRED_ZONE[roomType] ?? "any";
  if (prefZone === "any" || prefZone === zone) score += 20;
  else score -= 10;

  const adjTo = ADJACENT_TO[roomType] ?? [];
  for (const other of placed) {
    const shared = sharedEdgeLength(candidate, other.rect);
    if (shared > 0) {
      if (adjTo.includes(other.type)) score += shared * 2;
      else score -= shared * 0.5;
    }
  }
  return score;
}

function generateLayout(input) {
  const { floorplate, entryLocation, program } = input;

  // Generate corridors
  const corridorWidth = 5;
  const corridors = [];
  const spineY = floorplate.y + floorplate.height / 2 - corridorWidth / 2;
  corridors.push({
    id: "primary-spine", axis: "horizontal",
    rect: { x: floorplate.x, y: spineY, width: floorplate.width, height: corridorWidth },
  });
  if (floorplate.width >= 80) {
    const crossX = floorplate.x + floorplate.width / 2 - corridorWidth / 2;
    corridors.push({
      id: "cross-corridor", axis: "vertical",
      rect: { x: crossX, y: floorplate.y, width: corridorWidth, height: floorplate.height },
    });
  }

  // Flatten and sort instances
  const instances = [];
  for (const spec of program) {
    for (let i = 0; i < spec.count; i++) {
      instances.push({ type: spec.type, sqFt: spec.sqFt });
    }
  }
  instances.sort((a, b) =>
    (PLACEMENT_ORDER[a.type] ?? 99) - (PLACEMENT_ORDER[b.type] ?? 99)
  );

  const placed = [];
  const unplaced = [];
  const blockedRects = corridors.map(c => c.rect);
  const GRID = 2;

  for (const inst of instances) {
    const aspect = PREFERRED_ASPECTS[inst.type] ?? 1.4;
    const { width, height } = dimensionsFromArea(inst.sqFt, aspect);
    let bestRect = null;
    let bestScore = -Infinity;

    for (let cy = floorplate.y; cy + height <= floorplate.y + floorplate.height; cy += GRID) {
      for (let cx = floorplate.x; cx + width <= floorplate.x + floorplate.width; cx += GRID) {
        const candidate = { x: snap(cx, GRID), y: snap(cy, GRID), width, height };
        if (!contains(floorplate, candidate)) continue;
        const allBlocked = [...blockedRects, ...placed.map(p => p.rect)];
        if (allBlocked.some(b => overlaps(candidate, b))) continue;
        const score = scorePosition(candidate, floorplate, placed, inst.type);
        if (score > bestScore) { bestScore = score; bestRect = candidate; }
      }
    }

    if (bestRect) {
      const count = placed.filter(p => p.type === inst.type).length + 1;
      placed.push({
        id: `${inst.type.toLowerCase().replace(/\s+/g, "-")}-${count}`,
        type: inst.type,
        rect: bestRect,
        area: bestRect.width * bestRect.height,
        zone: zoneOf(bestRect, floorplate),
      });
    } else {
      unplaced.push({ type: inst.type, count: 1, reason: "No valid position found" });
    }
  }

  const placedSqFt = placed.reduce((s, r) => s + r.area, 0);
  const corridorSqFt = corridors.reduce((s, c) => s + c.rect.width * c.rect.height, 0);
  const totalSqFt = floorplate.width * floorplate.height;
  const residualSqFt = Math.max(0, totalSqFt - placedSqFt - corridorSqFt);
  const efficiencyScore = totalSqFt > 0 ? placedSqFt / totalSqFt : 0;

  return { rooms: placed, corridors, unplacedRooms: unplaced, efficiencyScore, placedSqFt, corridorSqFt, residualSqFt };
}

const ROOM_COLORS = {
  "Reception": "#D4AF37", "Open Workspace": "#2563EB", "Private Office": "#1E3A5F",
  "Conference Room": "#166534", "Huddle Room": "#14532D", "Break Room": "#78350F",
  "Collaboration Zone": "#0F766E", "Phone Booth": "#475569", "Lounge": "#7C3AED",
  "Storage": "#374151", "Server Room": "#1F2937", "Focus Room": "#065F46",
  "Print Area": "#4B5563", "IT Room": "#1E3A5F",
};

function renderToSVG(output, floorplate, label = "LEASIBILITY AI") {
  const SCALE = 8;
  const svgW = floorplate.width * SCALE;
  const svgH = floorplate.height * SCALE;

  function toSvg(r) {
    return {
      x: (r.x - floorplate.x) * SCALE,
      y: (floorplate.y + floorplate.height - r.y - r.height) * SCALE,
      w: r.width * SCALE, h: r.height * SCALE,
    };
  }

  let els = `<rect x="0" y="0" width="${svgW}" height="${svgH}" fill="#0F1F3D" stroke="#FFFFFF" stroke-width="3" rx="4"/>`;

  for (const corridor of output.corridors) {
    const c = toSvg(corridor.rect);
    els += `<rect x="${c.x}" y="${c.y}" width="${c.w}" height="${c.h}" fill="#FFFFFF" fill-opacity="0.08" stroke="#FFFFFF" stroke-width="0.5" stroke-dasharray="4,3"/>`;
    els += `<text x="${c.x + c.w/2}" y="${c.y + c.h/2 + 4}" font-size="7" fill="#FFFFFF60" font-family="sans-serif" text-anchor="middle" font-weight="600">CIRCULATION</text>`;
  }

  for (const room of output.rooms) {
    const r = toSvg(room.rect);
    const fill = ROOM_COLORS[room.type] ?? "#334155";
    const lines = room.type.split(" ");
    els += `<rect x="${r.x+1}" y="${r.y+1}" width="${r.w-2}" height="${r.h-2}" fill="${fill}" fill-opacity="0.85" stroke="#FFFFFF" stroke-width="1" rx="2"/>`;
    let ty = r.y + r.h/2 - (lines.length - 1) * 5;
    for (const line of lines) {
      els += `<text x="${r.x+r.w/2}" y="${ty}" font-size="9" fill="#FFFFFF" font-family="sans-serif" text-anchor="middle" font-weight="600">${line}</text>`;
      ty += 11;
    }
    els += `<text x="${r.x+r.w/2}" y="${r.y+r.h-6}" font-size="7" fill="#FFFFFF80" font-family="sans-serif" text-anchor="middle">${room.area.toLocaleString()} sf</text>`;
    const dr = Math.min(12, r.w*0.25, r.h*0.25);
    els += `<path d="M ${r.x+1} ${r.y+r.h-1} A ${dr} ${dr} 0 0 1 ${r.x+1+dr} ${r.y+r.h-1-dr}" fill="none" stroke="#FFFFFF60" stroke-width="0.8"/>`;
  }

  const eff = Math.round(output.efficiencyScore * 100);
  els += `<circle cx="${svgW-30}" cy="30" r="24" fill="#D4AF37" fill-opacity="0.15" stroke="#D4AF37" stroke-width="1.5"/>`;
  els += `<text x="${svgW-30}" y="27" font-size="11" fill="#D4AF37" font-family="sans-serif" text-anchor="middle" font-weight="700">${eff}%</text>`;
  els += `<text x="${svgW-30}" y="39" font-size="6" fill="#D4AF3790" font-family="sans-serif" text-anchor="middle">EFF</text>`;
  els += `<text x="${svgW/2}" y="${svgH-6}" font-size="8" fill="#D4AF3750" font-family="sans-serif" text-anchor="middle" font-weight="700">${label}</text>`;

  return `<svg viewBox="0 0 ${svgW} ${svgH}" xmlns="http://www.w3.org/2000/svg" style="background:#0F1F3D;border-radius:8px;width:100%;max-width:${svgW}px">\n  ${els}\n</svg>`;
}

// ── Run ───────────────────────────────────────────────────────
const inputPath  = join(__dirname, "sample-input.json");
const outputPath = join(__dirname, "sample-output.json");
const svgPath    = join(__dirname, "sample-output.svg");

const input = JSON.parse(readFileSync(inputPath, "utf8"));
console.log("Running layout engine...");

const layout = generateLayout(input);
const svg = renderToSVG(layout, input.floorplate, `LEASIBILITY AI — ${input.label ?? "TEST FIT"}`);

const output = {
  rooms: layout.rooms.map(r => ({
    id: r.id, type: r.type,
    position: { x: r.rect.x, y: r.rect.y },
    width: r.rect.width, height: r.rect.height,
    area: r.area, zone: r.zone,
  })),
  corridors: layout.corridors.map(c => ({
    id: c.id, axis: c.axis,
    x: c.rect.x, y: c.rect.y, width: c.rect.width, height: c.rect.height,
  })),
  unplacedRooms: layout.unplacedRooms,
  stats: {
    efficiencyScore:     layout.efficiencyScore,
    efficiencyPercent:   Math.round(layout.efficiencyScore * 100),
    placedSqFt:          layout.placedSqFt,
    corridorSqFt:        layout.corridorSqFt,
    residualSqFt:        layout.residualSqFt,
    totalFloorplateSqFt: input.floorplate.width * input.floorplate.height,
  },
};

writeFileSync(outputPath, JSON.stringify(output, null, 2));
writeFileSync(svgPath, svg);

console.log(`\n✓ sample-output.json written (${output.rooms.length} rooms placed, ${output.unplacedRooms.length} unplaced)`);
console.log(`✓ sample-output.svg written`);
console.log(`\nStats:`);
console.log(`  Efficiency:  ${output.stats.efficiencyPercent}%`);
console.log(`  Placed:      ${output.stats.placedSqFt.toLocaleString()} sf`);
console.log(`  Corridors:   ${output.stats.corridorSqFt.toLocaleString()} sf`);
console.log(`  Residual:    ${output.stats.residualSqFt.toLocaleString()} sf`);
console.log(`  Total plate: ${output.stats.totalFloorplateSqFt.toLocaleString()} sf`);
if (output.unplacedRooms.length > 0) {
  console.log(`\n⚠ Unplaced rooms:`);
  for (const u of output.unplacedRooms) console.log(`  - ${u.type}: ${u.reason}`);
}
