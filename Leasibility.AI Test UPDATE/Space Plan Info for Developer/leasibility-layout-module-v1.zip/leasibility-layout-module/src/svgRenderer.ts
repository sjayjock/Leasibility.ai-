/**
 * svgRenderer.ts
 * Converts a LayoutOutput into an SVG string for visual inspection.
 *
 * Coordinate system: the SVG canvas maps 1 ft → SCALE px.
 * All rooms are drawn as filled rectangles with labels.
 * Corridors are drawn as semi-transparent grey paths.
 */

import type { LayoutOutput } from "./layoutEngine";
import type { Rect } from "./geometry";

const SCALE = 8; // pixels per foot

const ROOM_COLORS: Record<string, string> = {
  "Reception":          "#D4AF37",
  "Open Workspace":     "#2563EB",
  "Private Office":     "#1E3A5F",
  "Conference Room":    "#166534",
  "Huddle Room":        "#14532D",
  "Break Room":         "#78350F",
  "Collaboration Zone": "#0F766E",
  "Phone Booth":        "#475569",
  "Lounge":             "#7C3AED",
  "Storage":            "#374151",
  "Server Room":        "#1F2937",
  "Focus Room":         "#065F46",
  "Print Area":         "#4B5563",
  "IT Room":            "#1E3A5F",
};

function toSvgCoords(r: Rect, floorplate: Rect): { x: number; y: number; w: number; h: number } {
  // Flip Y axis: SVG y=0 is top, our coordinate y=0 is bottom
  const svgX = (r.x - floorplate.x) * SCALE;
  const svgY = (floorplate.y + floorplate.height - r.y - r.height) * SCALE;
  return { x: svgX, y: svgY, w: r.width * SCALE, h: r.height * SCALE };
}

/**
 * Render a LayoutOutput to an SVG string.
 * Pass `floorplate` from the original LayoutInput.
 */
export function renderToSVG(
  output: LayoutOutput,
  floorplate: Rect,
  label = "LEASIBILITY AI — LAYOUT PREVIEW"
): string {
  const svgW = floorplate.width  * SCALE;
  const svgH = floorplate.height * SCALE;

  let elements = "";

  // ── Floorplate boundary ──────────────────────────────────────
  elements += `<rect x="0" y="0" width="${svgW}" height="${svgH}" fill="#0F1F3D" stroke="#FFFFFF" stroke-width="3" rx="4"/>`;

  // ── Corridors ────────────────────────────────────────────────
  for (const corridor of output.corridors) {
    const c = toSvgCoords(corridor.rect, floorplate);
    elements += `<rect x="${c.x}" y="${c.y}" width="${c.w}" height="${c.h}" fill="#FFFFFF" fill-opacity="0.08" stroke="#FFFFFF" stroke-width="0.5" stroke-dasharray="4,3"/>`;
    // Label
    const labelX = c.x + c.w / 2;
    const labelY = c.y + c.h / 2 + 4;
    elements += `<text x="${labelX}" y="${labelY}" font-size="7" fill="#FFFFFF60" font-family="sans-serif" text-anchor="middle" font-weight="600">CIRCULATION</text>`;
  }

  // ── Rooms ────────────────────────────────────────────────────
  for (const room of output.rooms) {
    const r = toSvgCoords(room.rect, floorplate);
    const fill = ROOM_COLORS[room.type] ?? "#334155";
    const labelLines = room.type.split(" ");

    elements += `<rect x="${r.x + 1}" y="${r.y + 1}" width="${r.w - 2}" height="${r.h - 2}" fill="${fill}" fill-opacity="0.85" stroke="#FFFFFF" stroke-width="1" rx="2"/>`;

    // Room type label (split into lines if needed)
    const textX = r.x + r.w / 2;
    let textY = r.y + r.h / 2 - (labelLines.length - 1) * 5;
    for (const line of labelLines) {
      elements += `<text x="${textX}" y="${textY}" font-size="9" fill="#FFFFFF" font-family="sans-serif" text-anchor="middle" font-weight="600">${line}</text>`;
      textY += 11;
    }

    // Area label
    elements += `<text x="${textX}" y="${r.y + r.h - 6}" font-size="7" fill="#FFFFFF80" font-family="sans-serif" text-anchor="middle">${room.area.toLocaleString()} sf</text>`;

    // Door arc (bottom-left corner, quarter circle)
    const doorR = Math.min(12, r.w * 0.25, r.h * 0.25);
    elements += `<path d="M ${r.x + 1} ${r.y + r.h - 1} A ${doorR} ${doorR} 0 0 1 ${r.x + 1 + doorR} ${r.y + r.h - 1 - doorR}" fill="none" stroke="#FFFFFF60" stroke-width="0.8"/>`;
    elements += `<line x1="${r.x + 1}" y1="${r.y + r.h - 1}" x2="${r.x + 1 + doorR}" y2="${r.y + r.h - 1}" stroke="#FFFFFF60" stroke-width="0.8"/>`;
  }

  // ── Efficiency badge ─────────────────────────────────────────
  const eff = Math.round(output.efficiencyScore * 100);
  elements += `<circle cx="${svgW - 30}" cy="30" r="24" fill="#D4AF37" fill-opacity="0.15" stroke="#D4AF37" stroke-width="1.5"/>`;
  elements += `<text x="${svgW - 30}" y="27" font-size="11" fill="#D4AF37" font-family="sans-serif" text-anchor="middle" font-weight="700">${eff}%</text>`;
  elements += `<text x="${svgW - 30}" y="39" font-size="6" fill="#D4AF3790" font-family="sans-serif" text-anchor="middle">EFF</text>`;

  // ── Footer label ─────────────────────────────────────────────
  elements += `<text x="${svgW / 2}" y="${svgH - 6}" font-size="8" fill="#D4AF3750" font-family="sans-serif" text-anchor="middle" font-weight="700">${label}</text>`;

  return `<svg viewBox="0 0 ${svgW} ${svgH}" xmlns="http://www.w3.org/2000/svg" style="background:#0F1F3D;border-radius:8px;width:100%;max-width:${svgW}px">
  ${elements}
</svg>`;
}
